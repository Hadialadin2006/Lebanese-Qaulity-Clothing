document.addEventListener('DOMContentLoaded', function () {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartButtons = document.querySelectorAll('.add-to-cart');

    cartButtons.forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const size = document.getElementById('product-size').value;
            const quantity = parseInt(document.getElementById('product-quantity').value);
            
            if (!size) {
                alert('Please select a size.');
                return;
            }

            const product = {
                name: this.dataset.product,
                price: parseFloat(this.dataset.price),
                image: this.dataset.image,
                size: size,
                quantity: quantity
            };
            addToCart(product);
        });
    });

    function addToCart(product) {
        const existingProduct = cart.find(item => item.name === product.name && item.size === product.size);
        if (existingProduct) {
            existingProduct.quantity += product.quantity;
        } else {
            cart.push(product);
        }
        localStorage.setItem('cart', JSON.stringify(cart));
        window.location.href = 'cart.html';
    }

    function displayCartItems() {
        const cartItemsContainer = document.getElementById('cart-items');
        const cartTotalContainer = document.getElementById('cart-total');
        let total = 0;

        cartItemsContainer.innerHTML = '';

        cart.forEach(item => {
            const itemTotal = item.quantity * item.price;
            total += itemTotal;

            const cartItem = document.createElement('div');
            cartItem.classList.add('cart-item');

            cartItem.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <div class="cart-item-details">
                    <p>${item.name} - Size: ${item.size}</p>
                    <p>${item.price} Fr. x <span class="quantity">${item.quantity}</span> = ${itemTotal.toFixed(2)} Fr.</p>
                </div>
                <div class="cart-actions">
                    <button class="decrease" data-name="${item.name}" data-size="${item.size}">-</button>
                    <button class="increase" data-name="${item.name}" data-size="${item.size}">+</button>
                    <button class="remove" data-name="${item.name}" data-size="${item.size}">Remove</button>
                </div>
            `;

            cartItemsContainer.appendChild(cartItem);
        });

        cartTotalContainer.innerText = total.toFixed(2);

        // Add event listeners for the action buttons
        document.querySelectorAll('.decrease').forEach(button => {
            button.addEventListener('click', decreaseQuantity);
        });
        document.querySelectorAll('.increase').forEach(button => {
            button.addEventListener('click', increaseQuantity);
        });
        document.querySelectorAll('.remove').forEach(button => {
            button.addEventListener('click', removeFromCart);
        });
    }

    function decreaseQuantity(event) {
        const name = event.target.dataset.name;
        const size = event.target.dataset.size;
        const product = cart.find(item => item.name === name && item.size === size);
        if (product.quantity > 1) {
            product.quantity -= 1;
        } else {
            cart.splice(cart.indexOf(product), 1);
        }
        updateCart();
    }

    function increaseQuantity(event) {
        const name = event.target.dataset.name;
        const size = event.target.dataset.size;
        const product = cart.find(item => item.name === name && item.size === size);
        product.quantity += 1;
        updateCart();
    }

    function removeFromCart(event) {
        const name = event.target.dataset.name;
        const size = event.target.dataset.size;
        const product = cart.find(item => item.name === name && item.size === size);
        cart.splice(cart.indexOf(product), 1);
        updateCart();
    }

    function updateCart() {
        localStorage.setItem('cart', JSON.stringify(cart));
        displayCartItems();
    }

    if (window.location.pathname.includes('cart.html')) {
        displayCartItems();
    }
});
